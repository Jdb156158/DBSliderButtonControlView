//
//  SEFilterKnob.h
//  DBSlideButtonControl
//
//  Created by Jdb on 16/3/26.
//  Copyright © 2016年 uimbank. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SEFilterKnob : UIButton
@property(nonatomic, strong) UIColor *handlerColor;
@end
